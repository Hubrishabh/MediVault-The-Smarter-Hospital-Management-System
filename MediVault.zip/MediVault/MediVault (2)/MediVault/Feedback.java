import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.util.ArrayList;

public class Feedback extends JFrame {
    private int rating = 0;
    private final JLabel[] stars = new JLabel[5];
    private final JTextField reasonField = new JTextField(30);
    private final JTextField emailField = new JTextField(30);
    private final JTextField patientIdField = new JTextField(10);
    private final JTextField doctorNameField = new JTextField(10);
    private final JTextArea commentsArea = new JTextArea(5, 30);
    private final JButton submitButton = new JButton("Submit Feedback");

    private final String DB_URL = "jdbc:mysql://localhost:3306/MediVault";
    private final String DB_USER = "root";
    private final String DB_PASS = "tanisha";

    public Feedback() {
        setTitle("💬 We Value Your Feedback");
        setSize(500, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10)); 
        setResizable(false);

        JPanel topPanel = new JPanel(new BorderLayout()); 
        JLabel promptLabel = new JLabel("How would you rate your experience with MediVault?");
        promptLabel.setFont(new Font("Segoe UI", Font.BOLD, 16)); 
        promptLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); 
        topPanel.add(promptLabel, BorderLayout.NORTH);  

        JPanel starsPanel = new JPanel(new FlowLayout()); 
        for (int i = 0; i < 5; i++) {
            JLabel star = new JLabel("☆");
            star.setFont(new Font("SansSerif", Font.PLAIN, 36)); 
            int index = i;
            star.setCursor(new Cursor(Cursor.HAND_CURSOR)); 
            star.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    rating = index + 1;
                    updateStars();
                }
            });
            stars[i] = star;
            starsPanel.add(star);
        }
        topPanel.add(starsPanel, BorderLayout.CENTER);
        add(topPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(0, 1, 10, 10)); 
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));

        formPanel.add(new JLabel("Patient ID:"));
        formPanel.add(patientIdField);

        formPanel.add(new JLabel("Doctor Name:"));
        formPanel.add(doctorNameField);

        formPanel.add(new JLabel("Additional comments (message):"));
        commentsArea.setBorder(BorderFactory.createLineBorder(Color.GRAY)); 
        formPanel.add(new JScrollPane(commentsArea));

        formPanel.add(new JLabel("Your email (optional):"));
        formPanel.add(emailField);

        formPanel.add(new JLabel("Why this rating? (optional):"));
        formPanel.add(reasonField);

        add(formPanel, BorderLayout.CENTER);

        submitButton.setFont(new Font("Segoe UI", Font.BOLD, 14)); 
        submitButton.setBackground(new Color(44, 167, 110)); 
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        submitButton.addActionListener(e -> submitFeedback()); 
        add(submitButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void updateStars() {
        for (int i = 0; i < 5; i++) {
            stars[i].setText(i < rating ? "★" : "☆");
        }
    }

    private void submitFeedback() {
        String patientIdText = patientIdField.getText().trim();
        String doctorName = doctorNameField.getText().trim();
        String message = commentsArea.getText().trim();
        String email = emailField.getText().trim();
        String reason = reasonField.getText().trim();

        if (rating == 0 || patientIdText.isEmpty() ||
                doctorName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all required fields and select a rating.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String sql = "INSERT INTO feedback (patient_id, rating, message, email, why_this_rating, doctor_name) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, Integer.parseInt(patientIdText)); 
                stmt.setInt(2, rating);
                stmt.setString(3, message);
                stmt.setString(4, email);
                stmt.setString(5, reason);
                stmt.setString(6, doctorName);

                int rowsInserted = stmt.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(this, "✅ Thank you for your feedback!", "Submitted", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to submit feedback.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Please enter a valid numeric Patient ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static ArrayList<String> getAllFeedback() {
        ArrayList<String> feedbackList = new ArrayList<>();
        String DB_URL = "jdbc:mysql://localhost:3306/MediVault";
        String DB_USER = "root";
        String DB_PASS = "tanisha";

        try (java.sql.Connection conn = java.sql.DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String sql = "SELECT patient_id, doctor_name, rating, message FROM feedback";
            try (java.sql.PreparedStatement ps = conn.prepareStatement(sql);
                 java.sql.ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    int patientId = rs.getInt("patient_id");
                    String doctor = rs.getString("doctor_name");
                    int rate = rs.getInt("rating");
                    String message = rs.getString("message");

                    String feedback = "Patient ID: " + patientId + 
                                      ", Doctor: " + doctor + 
                                      ", Rating: " + rate + "/5\nMessage: " + message;

                    feedbackList.add(feedback);
                }
            }
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
        return feedbackList;
    }
}