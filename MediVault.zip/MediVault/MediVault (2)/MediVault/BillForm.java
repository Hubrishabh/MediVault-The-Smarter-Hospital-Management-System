import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Year;
import java.util.Vector;

public class BillForm extends JFrame {
    private Connection connection;

    public BillForm() {
        setTitle("Bill Form");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // Set up a clean and structured layout
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(8, 2, 10, 10));  // Increased row count to accommodate new fields
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(248, 250, 255));

        // Font settings for consistency
        Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 13);

        // Form fields for Bill details
        JLabel patientIdLabel = new JLabel("Patient ID:");
        patientIdLabel.setFont(labelFont);
        JTextField patientIdField = createStyledTextField(fieldFont);

        JLabel patientNameLabel = new JLabel("Patient Name:");
        patientNameLabel.setFont(labelFont);
        JTextField patientNameField = createStyledTextField(fieldFont);

        JLabel billDateLabel = new JLabel("Bill Date:");
        billDateLabel.setFont(labelFont);

        // Create day, month, and year combo boxes for date input
        JComboBox<String> dayBox = new JComboBox<>(getDays());
        JComboBox<String> monthBox = new JComboBox<>(getMonths());
        JComboBox<String> yearBox = new JComboBox<>(getYears());

        JPanel datePanel = new JPanel();
        datePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
        datePanel.add(dayBox);
        datePanel.add(monthBox);
        datePanel.add(yearBox);

        JLabel treatmentLabel = new JLabel("Treatment Type:");
        treatmentLabel.setFont(labelFont);
        JComboBox<String> treatmentComboBox = new JComboBox<>(new String[]{"General", "Surgery", "Consultation"});

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setFont(labelFont);
        JTextField amountField = createStyledTextField(fieldFont);

        JLabel doctorNameLabel = new JLabel("Doctor Name:");
        doctorNameLabel.setFont(labelFont);

        // Updated list of doctors
        JComboBox<String> doctorComboBox = new JComboBox<>(new String[]{
                "Dr. Kiran Bedi", "Dr. Amit Roy", "Dr. Sneha Kapoor", "Dr. Rohan Mehra", "Dr. Tara Deshpande", "Dr. Vishal Rana",
                "Dr. Kavita Joshi", "Dr. Sameer Arora", "Dr. Nidhi Chauhan", "Dr. Abhay Menon", "Dr. Rina Das", "Dr. Kunal Sethi",
                "Dr. Pooja Nair", "Dr. Dev Sharma", "Dr. Ananya Bose", "Dr. Rajeev Pillai", "Dr. Ruchi Singh", "Dr. Harsh Tiwari",
                "Dr. Meena Shah", "Dr. Arvind Joshi", "Dr. Aakash Sharma", "Dr. Priya Patel", "Dr. Rajesh Kumar", "Dr. Anjali Gupta",
                "Dr. Ravi Desai", "Dr. Neha Reddy", "Dr. Suresh Iyer", "Dr. Shruti Mehta", "Dr. Manoj Yadav", "Dr. Rekha Verma"
        });

        JLabel paymentStatusLabel = new JLabel("Payment Status:");
        paymentStatusLabel.setFont(labelFont);
        JComboBox<String> paymentStatusCombo = new JComboBox<>(new String[]{"Paid", "Pending", "Overdue"});

        // Add components to the panel
        panel.add(patientIdLabel);
        panel.add(patientIdField);
        panel.add(patientNameLabel);
        panel.add(patientNameField);
        panel.add(billDateLabel);
        panel.add(datePanel);
        panel.add(treatmentLabel);
        panel.add(treatmentComboBox);
        panel.add(amountLabel);
        panel.add(amountField);
        panel.add(doctorNameLabel);
        panel.add(doctorComboBox);
        panel.add(paymentStatusLabel);
        panel.add(paymentStatusCombo);

        // Save and Cancel buttons
        JButton saveButton = createStyledButton("Save", new Color(46, 204, 113));
        JButton cancelButton = createStyledButton("Cancel", new Color(231, 76, 60));

        // Save button action
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String patientId = patientIdField.getText().trim();
                String patientName = patientNameField.getText().trim();

                // Mapping month abbreviation to number
                String monthStr = monthBox.getSelectedItem().toString();
                String monthNum = String.format("%02d", monthBox.getSelectedIndex() + 1); // Jan=0, so +1
                String day = dayBox.getSelectedItem().toString();
                String year = yearBox.getSelectedItem().toString();

// Correct format: YYYY-MM-DD
                String billDate = year + "-" + monthNum + "-" + day;

                String treatment = treatmentComboBox.getSelectedItem().toString();
                String amount = amountField.getText().trim();
                String doctorName = doctorComboBox.getSelectedItem().toString();
                String paymentStatus = paymentStatusCombo.getSelectedItem().toString();

                // Check for empty fields
                if (patientId.isEmpty() || patientName.isEmpty() || amount.isEmpty()) {
                    JOptionPane.showMessageDialog(BillForm.this, "Please fill all required fields!", "Warning", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Save bill details to the database before proceeding to PaymentForm
                saveBillToDatabase(patientId, patientName, billDate, treatment, amount, doctorName, paymentStatus);

                // Show confirmation dialog
                JOptionPane.showMessageDialog(BillForm.this,
                        "Bill Saved for:\nPatient ID: " + patientId + "\nPatient Name: " + patientName + "\nDate: " + billDate,
                        "Success", JOptionPane.INFORMATION_MESSAGE);

                // Open the PaymentForm after saving the bill
                new PaymentForm();
                dispose(); // Optionally dispose of the BillForm window after redirection
            }
        });

        // Cancel button action
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                patientIdField.setText("");
                patientNameField.setText("");
                amountField.setText("");
                dayBox.setSelectedIndex(0);
                monthBox.setSelectedIndex(0);
                yearBox.setSelectedIndex(0);
                treatmentComboBox.setSelectedIndex(0);
                doctorComboBox.setSelectedIndex(0);
                paymentStatusCombo.setSelectedIndex(0);
            }
        });

        // Button panel for Save/Cancel buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(248, 250, 255));
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        // Adding components to the JFrame
        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);

        // Set up database connection
        setupDatabaseConnection();
    }

    // Create a text field with custom style
    private JTextField createStyledTextField(Font font) {
        JTextField field = new JTextField();
        field.setFont(font);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 200, 240)),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }

    // Create styled buttons
    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        return button;
    }

    private String[] getDays() {
        String[] days = new String[31];
        for (int i = 1; i <= 31; i++) {
            days[i - 1] = String.format("%02d", i);
        }
        return days;
    }

    private String[] getMonths() {
        return new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    }

    private String[] getYears() {
        int currentYear = Year.now().getValue();
        Vector<String> years = new Vector<>();
        for (int i = currentYear; i >= 1900; i--) {
            years.add(String.valueOf(i));
        }
        return years.toArray(new String[0]);
    }

    private void setupDatabaseConnection() {
        try {
            // Database connection details
            String url = "jdbc:mysql://localhost:3306/MediVault";
            String username = "root";
            String password = "tanisha"; // your actual password

            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Database connected successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void saveBillToDatabase(String patientId, String patientName, String billDate, String treatment, String amount, String doctorName, String paymentStatus) {
        String insertSQL = "INSERT INTO billing (patient_id, patient_name, bill_date, treatment_type, amount, doctor_name, payment_status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(insertSQL)) {
            pstmt.setInt(1, Integer.parseInt(patientId));
            pstmt.setString(2, patientName);
            pstmt.setString(3, billDate);
            pstmt.setString(4, treatment);
            pstmt.setString(5, amount);
            pstmt.setString(6, doctorName);
            pstmt.setString(7, paymentStatus);

            pstmt.executeUpdate();
            System.out.println("Bill details saved successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving bill details: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(BillForm::new);
    }
}
